<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-employment-type" only-nested=true}}
{{job-employment-type }}
