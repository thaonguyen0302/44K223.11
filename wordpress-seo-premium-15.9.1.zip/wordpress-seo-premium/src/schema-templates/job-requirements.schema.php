<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-requirements" only-nested=true }}
{{list name="requirements" tag="li" allowed-tags=[ "h1","h2","h3","h4","h5","h6","br","a","p","b","strong","i","em" ] }}
