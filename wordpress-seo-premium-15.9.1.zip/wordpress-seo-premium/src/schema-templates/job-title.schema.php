<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-title" only-nested=true}}
{
	"name": {{html name="title"}}
}
