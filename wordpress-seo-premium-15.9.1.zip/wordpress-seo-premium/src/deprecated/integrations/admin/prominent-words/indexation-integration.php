<?php

namespace Yoast\WP\SEO\Integrations\Admin\Prominent_Words;

/**
 * Class Indexation_Integration. Indexing integration for prominent words.
 *
 * @deprecated 15.2
 * @codeCoverageIgnore
 */
class Indexation_Integration extends Indexing_Integration {

}
